<section class="ftco-section ftco-services">
    	<div class="overlay"></div>
    	<div class="container">
    		<div class="row justify-content-center mb-5 pb-3">
          <div class="col-md-7 heading-section ftco-animate text-center">
            <h2 class="mb-4">Our Offerings</h2>
            <p>Pizza is a most wonderfull thing in our life which not fill our stomach and also glide the soft smoothness in our mind</p>
          </div>
        </div> 
    		<div class="row">
          <div class="col-md-4 ftco-animate">
            <div class="media d-block text-center block-6 services">
              <div class="icon d-flex justify-content-center align-items-center mb-5">
              	<span class="flaticon-diet"></span>
              </div>
              <div class="media-body">
                <h3 class="heading">Healthy Foods</h3>
                <p>A healthy diet is a solution to many of our health-care problems. It's the most important solution.</p>
              </div>
            </div>      
          </div> 
          <div class="col-md-4 ftco-animate">
            <div class="media d-block text-center block-6 services">
              <div class="icon d-flex justify-content-center align-items-center mb-5">
              	<span class="flaticon-bicycle"></span>
              </div>
              <div class="media-body">
                <h3 class="heading">Fastest Delivery</h3>
                <p>We offer tracking and pizza delivery services. Track parcels and packages in express manner!</p>
              </div>
            </div>      
          </div>
          <div class="col-md-4 ftco-animate">
            <div class="media d-block text-center block-6 services">
              <div class="icon d-flex justify-content-center align-items-center mb-5"><span class="flaticon-pizza-1"></span></div>
              <div class="media-body">
                <h3 class="heading">Original Recipes</h3>
                <p>Traditional Style pizza is a relatively simple food,made with flour ,yeast,water,slat,iol,tomoto sauce and fresh cheess..</p>
              </div>
            </div>    
          </div>
        </div>
    	</div>
    </section>