<section class="ftco-about d-md-flex">
  <div class="one-half img" style="background-image: url(images/about.jpg);"></div>
  <div class="one-half ftco-animate">
    <div class="heading-section ftco-animate ">
      <h2 class="mb-4">Welcome to <img src="images/bg_1.png" alt="logo Image" width="25%">
      <pre style="color: white;text-transform: initial">NEW YORK<span style="
    font-family: cursive;font-style: oblique;color: red;font-weight: 600;text-transform: capitalize"> Pizza</span>.co
      </pre>
    </h2>
    </div>
    <div>
    	<p>Pizza made with ingredients typical of Mexican cuisine. The usual toppings that can be found throughout Mexico are chorizo, jalapeño pepper slices, grilled or fried onions, tomato, chilli pepper, shrimp, avocado, and sometimes beef, bell peppers, tripas or scallop. This pizza has the usual marinara sauce or white sauce and mozzarella cheese. Variations, substituting pepper jack cheese or Oaxaca cheese for mozzarella, are also popular.</p>
    </div>
  </div>
</section>