<!DOCTYPE html>
<html lang="en">
  <?php include("comp/head.php"); ?>
  <body>
  	<?php include("comp/navbar.php"); ?>
    
    <?php include("comp/slide.php"); ?>

    <?php include("comp/social.php"); ?>
    
    <?php include("comp/welcome.php"); ?>

    <?php include("comp/service.php"); ?>

    <?php //include("comp/hmeal.php"); ?>

    <?php include("comp/gallary.php"); ?>

		<?php include("comp/counter.php"); ?>

    <?php include("comp/category.php"); ?>

    <?php //include("comp/blog.php"); ?>

		<?php //include("comp/contact.php"); ?>
		
    <?php include("comp/footer.php"); ?>
    
    <?php include("comp/foot.php"); ?> 
  </body>
</html>