<!DOCTYPE html>
<html lang="en">
  <?php include("comp/head.php"); ?>
  <body>

    <?php include("comp/navbar.php"); ?>

    <?php include("comp/slide.php"); ?>
    
<!-- 	<?php include("comp/hmeal.php"); ?> -->

    <?php include("comp/category.php"); ?>

    <?php include("comp/footer.php"); ?>
    
    <?php include("comp/foot.php"); ?> 
    
  </body>
</html>